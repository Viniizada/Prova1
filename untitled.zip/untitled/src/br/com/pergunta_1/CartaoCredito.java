package br.com.pergunta_1;

public class CartaoCredito extends Pagamento {

    String numcartao;
    String bandeiracartao;
    String titularcartao;

    public CartaoCredito(String dataHoraPagamento, int numeroPagamento, double valorPago, String numcartao,
                         String bandeiracartao, String titularcartao) {
        super(dataHoraPagamento, numeroPagamento, valorPago);
        this.numcartao = numcartao;
        this.bandeiracartao = bandeiracartao;
        this.titularcartao = titularcartao;
    }

    public CartaoCredito() {
        super();
    }

    public String getNumcartao() {
        return numcartao;
    }

    public void setNumcartao(String numcartao) {
        this.numcartao = numcartao;
    }

    public String getBandeiracartao() {
        return bandeiracartao;
    }

    public void setBandeiracartao(String bandeiracartao) {
        this.bandeiracartao = bandeiracartao;
    }

    public String getTitularcartao() {
        return titularcartao;
    }

    public void setTitularcartao(String titularcartao) {
        this.titularcartao = titularcartao;
    }



    @Override
    public String imprimirCupomFiscal() {
        return " Titular do Cartão: "+ getTitularcartao()+"\nNúmero do Cartão: "+ getNumcartao()+
                "\nBandeira do Cartão: "+ getBandeiracartao()+"\nValor Pago: "+ getValorPago()+
                "\nData e Hora do Pagamento: "+ getDataHoraPagamento()+"\n do Pagamento: "+ getNumeroPagamento();
    }
}
