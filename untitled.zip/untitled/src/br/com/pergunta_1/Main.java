package br.com.pergunta_1;

public class Main {
    public static void main(String[] args) {

        CartaoCredito cc1 = new CartaoCredito();
        cc1.setTitularcartao("Ana");
        cc1.setNumcartao("******");
        cc1.setBandeiracartao("*****");
        cc1.setValorPago(1000);
        cc1.setNumeroPagamento(12890);
        cc1.setDataHoraPagamento(18/04/2023+21+":"+40);


        System.out.println(cc1.imprimirCupomFiscal());

        Pix p1 = new Pix();
        p1.setValorPago(1000);
        p1.setNumeroPagamento(12890);
        p1.setDataHoraPagamento(18/04/2023+21+":"+40);


        System.out.println(cc1.imprimirCupomFiscal());

        CartaoDebito cd1 = new CartaoDebito();
        cd1.setTitularcartao("Ana");
        cd1.setNumcartao("******");
        cd1.setValorPago(1000);
        cd1.setNumeroPagamento(12890);
        cd1.setDataHoraPagamento(18/04/2023+21+":"+40);


        System.out.println(cc1.imprimirCupomFiscal());
    }
}