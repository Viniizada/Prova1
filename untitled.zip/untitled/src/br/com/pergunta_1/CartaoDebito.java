package br.com.pergunta_1;

public class CartaoDebito extends Pagamento {

    private String numcartao;
    private String titularcartao;

    public CartaoDebito() {

    }

    public String getNumcartao() {
        return numcartao;
    }

    public CartaoDebito(String dataHoraPagamento, int numeroPagamento, double valorPago, String numcartao,
                        String titularcartao) {
        super(dataHoraPagamento, numeroPagamento, valorPago);
        this.numcartao = numcartao;
        this.titularcartao = titularcartao;
    }

    public void setNumcartao(String numcartao) {
        this.numcartao = numcartao;
    }

    public String getTitularcartao() {
        return titularcartao;
    }

    public void setTitularcartao(String titularcartao) {
        this.titularcartao = titularcartao;
    }


    @Override
    public String imprimirCupomFiscal() {
        return null;
    }
}
